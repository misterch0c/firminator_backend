#!/bin/sh
/bin/sed 's/$'"/`echo \\\r`/" /var/log/messages
