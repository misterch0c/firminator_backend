#!/bin/sh
if [[ -z "$1" ]]; then exit 1; fi
if [[ -z "$2" ]]; then exit 1; fi
devname=$1
filename=$2
res=""
pass=false

saveIFS=$IFS; IFS=$'\n';
for line in $(/bin/ethtool -t ${devname} offline 2>&1)
do
 if [ -z "${line##*PASS*}" ]
  then
   pass=true
 fi
 if [ -z "${line##*pair*}" ]
  then
   res="$res\"pair`echo ${line} | awk '{print $3}'`\":`echo ${line} | awk '{print $6}'`,"
 fi
done
IFS=$saveIFS

res="$res\"pass\":$pass"
echo ${res}>"/tmp/$filename"

exit 0