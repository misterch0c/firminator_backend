<?php
	require_once 'include/libs/Smarty.class.php';
	$template->display('titleLogo.tpl');
?>
